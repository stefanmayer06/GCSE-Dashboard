---
name: seo-optimization
description: Use when optimizing web pages for search engines with on-page SEO, technical SEO, or content strategy.
---

# SEO Optimization

## When to Use This Skill
- Optimizing meta tags, headings, and page structure
- Setting up sitemaps, robots.txt, and structured data
- Improving Core Web Vitals for search ranking
- Planning content strategy for organic traffic

## Workflow
1. Audit the page: check meta tags, headings, image alt text, and URL structure
2. Optimize meta tags: title under 60 chars, description under 160 chars
3. Structure headings: one H1 per page, logical H2-H6 hierarchy
4. Add structured data: JSON-LD for articles, products, or FAQs
5. Generate a sitemap: ensure all important pages are included
6. Configure robots.txt: block non-public pages, allow crawling
7. Improve Core Web Vitals: LCP, INP, CLS
8. Monitor: track rankings, clicks, and impressions in Search Console

## Rules
- Write meta descriptions for humans, not search engines
- Use descriptive URLs: `/docs/getting-started`, not `/docs/123`
- Add alt text to every image — describe what the image shows
- Don't keyword-stuff — write naturally for the reader
- Use internal links to connect related content
- Update stale content — freshness matters for search ranking
